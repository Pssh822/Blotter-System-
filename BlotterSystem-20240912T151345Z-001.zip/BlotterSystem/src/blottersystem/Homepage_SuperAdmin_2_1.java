/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package blottersystem;

import java.io.ByteArrayInputStream;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.LegendItem;
import org.jfree.chart.LegendItemCollection;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author jcram
 */
public class Homepage_SuperAdmin_2_1 extends javax.swing.JFrame {
    private ArrayList<ImageIcon> images;
    private int currentIndex = 0;
    PreparedStatement pst = null;
    ResultSet rs = null;
    Connection conn = BlotterSystem.connect();
    
   
    public Homepage_SuperAdmin_2_1() {
        initComponents();

        dt();
        timer();
        CaseNumber();
        BlotterTable();
        status_label();
        status_label1();
        status_label2();
        status_label3();
        BlotterTable1();
        TODAY();
        loadImages();

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        Announce_bt.setBackground(new Color(0, 102, 204));
        Update_bt.setBackground(new Color(240, 240, 240));
        Addblotter_bt.setBackground(new Color(240, 240, 240));
        view_bt.setBackground(new Color(240, 240, 240));
        status_bt.setBackground(new Color(240, 240, 240));

        announce_pl.setVisible(true);
        update_pl.setVisible(false);
        addblotter_pl.setVisible(false);
        view_pl.setVisible(false);
        status_pl.setVisible(false);
        
        showImageAndWhatsNew();
//        initSlideshow();

    }
     public void dt() {
    Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM-dd-yyyy");
        String dd = sdf.format(d);
        date.setText(dd);   
    }
      Timer t;
    SimpleDateFormat st;
    public void timer(){
    t = new Timer(5000, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

        Date dt = new Date();
        st = new SimpleDateFormat("hh:mm:ss a");
        String tt = st.format(dt);
        time.setText(tt);
        
        if (currentIndex >= images.size()) {
                    currentIndex = 0;
                }
            ImageIcon resizedIcon = resizeImageIcon(images.get(currentIndex), 550, 310);
            IMAGE_SHARE.setIcon(resizedIcon);
            currentIndex++;
        }
    });
    t.start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        UPDATE = new javax.swing.JDialog();
        jLabel28 = new javax.swing.JLabel();
        case_num = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        name_com_edit = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        add_com_edit = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        report_edit = new javax.swing.JTextArea();
        jLabel32 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        loc_edit = new javax.swing.JTextArea();
        jScrollPane11 = new javax.swing.JScrollPane();
        detail_edit = new javax.swing.JTextArea();
        jLabel33 = new javax.swing.JLabel();
        add_acc_edit = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        name_acc_edit = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        EDIT = new javax.swing.JMenuItem();
        update_status = new javax.swing.JMenuItem();
        DELETE = new javax.swing.JMenuItem();
        Status = new javax.swing.JDialog();
        jLabel46 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        update_status_btn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Contact = new javax.swing.JDialog();
        jPanel14 = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        jLabel65 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        Code = new javax.swing.JDialog();
        jPanel16 = new javax.swing.JPanel();
        jLabel66 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        X_CODE = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        code_tf = new javax.swing.JPasswordField();
        Help = new javax.swing.JFrame();
        jLabel69 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel18 = new javax.swing.JPanel();
        jLabel70 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jLabel81 = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jLabel82 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jLabel83 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel84 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel86 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        jLabel87 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel88 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel90 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        schedule = new javax.swing.JFrame();
        jPanel28 = new javax.swing.JPanel();
        sched_date = new com.toedter.calendar.JDateChooser();
        jLabel73 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        sched_time = new javax.swing.JTextField();
        update_on_sched = new javax.swing.JButton();
        combo_day = new javax.swing.JComboBox<>();
        Head_Panel = new javax.swing.JPanel();
        date = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        DashBoard_BT = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        Announce_bt = new javax.swing.JButton();
        Addblotter_bt = new javax.swing.JButton();
        view_bt = new javax.swing.JButton();
        status_bt = new javax.swing.JButton();
        Update_bt = new javax.swing.JButton();
        contact1 = new javax.swing.JLabel();
        help = new javax.swing.JLabel();
        contact = new javax.swing.JLabel();
        username_homepage = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Dashboard_PL = new javax.swing.JPanel();
        announce_pl = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        IMAGE_SHARE = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        WhatsNew = new javax.swing.JTextArea();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        today_sched = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        update_pl = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        IMG4 = new javax.swing.JLabel();
        IMG5 = new javax.swing.JLabel();
        IMG6 = new javax.swing.JLabel();
        UploadIMG1 = new javax.swing.JButton();
        UploadIMG2 = new javax.swing.JButton();
        UpdateText = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        WhatsNew1 = new javax.swing.JTextArea();
        UploadIMG3 = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        addblotter_pl = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        case1 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        report_ta = new javax.swing.JTextArea();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        location_ta = new javax.swing.JTextArea();
        jLabel19 = new javax.swing.JLabel();
        name_complainant = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        address_complainant = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        name_accuse = new javax.swing.JTextField();
        address_accuse = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        detailed_report_ta = new javax.swing.JTextArea();
        add_btn = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        view_pl = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        set = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        unset = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        sched = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        unsched = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        searchbar_tf = new javax.swing.JTextField();
        jScrollPane8 = new javax.swing.JScrollPane();
        blotters_table = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        status_pl = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        searchbar_tf1 = new javax.swing.JTextField();
        jScrollPane13 = new javax.swing.JScrollPane();
        blotters_table1 = new javax.swing.JTable();
        jScrollPane14 = new javax.swing.JScrollPane();
        PrintPanel = new javax.swing.JPanel();
        jLabel53 = new javax.swing.JLabel();
        jLabel48 = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel85 = new javax.swing.JLabel();
        jLabel89 = new javax.swing.JLabel();
        sched_time_today = new javax.swing.JLabel();
        jLabel95 = new javax.swing.JLabel();
        reportname = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        casename = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        comname = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel108 = new javax.swing.JLabel();
        accname = new javax.swing.JLabel();
        jLabel109 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        comname1 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel116 = new javax.swing.JLabel();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jLabel94 = new javax.swing.JLabel();
        jLabel96 = new javax.swing.JLabel();
        date_today1 = new javax.swing.JLabel();
        sched_date_today1 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        Print = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        UPDATE.setTitle("UPDATE");
        UPDATE.setResizable(false);
        UPDATE.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("CASE:");
        UPDATE.getContentPane().add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 50, 30));

        case_num.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        case_num.setForeground(new java.awt.Color(255, 255, 255));
        case_num.setText("000");
        UPDATE.getContentPane().add(case_num, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 40, 30));

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Complainant:");
        UPDATE.getContentPane().add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 120, 30));

        name_com_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        UPDATE.getContentPane().add(name_com_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 320, 40));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Address Of Complainant:");
        UPDATE.getContentPane().add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 220, 30));

        add_com_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        UPDATE.getContentPane().add(add_com_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 320, 40));

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Report:");
        UPDATE.getContentPane().add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 70, 30));

        report_edit.setColumns(20);
        report_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        report_edit.setRows(5);
        jScrollPane9.setViewportView(report_edit);

        UPDATE.getContentPane().add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 320, 110));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("Location:");
        UPDATE.getContentPane().add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 100, 30));

        loc_edit.setColumns(20);
        loc_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        loc_edit.setRows(5);
        jScrollPane10.setViewportView(loc_edit);

        UPDATE.getContentPane().add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 320, 90));

        detail_edit.setColumns(20);
        detail_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        detail_edit.setRows(5);
        jScrollPane11.setViewportView(detail_edit);

        UPDATE.getContentPane().add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 230, 320, 180));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText("Detailed Report:");
        UPDATE.getContentPane().add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, 220, 30));

        add_acc_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        UPDATE.getContentPane().add(add_acc_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 150, 320, 40));

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("Address Of Accused:");
        UPDATE.getContentPane().add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 120, 220, 30));

        name_acc_edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        UPDATE.getContentPane().add(name_acc_edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 80, 320, 40));

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setText("Accused:");
        UPDATE.getContentPane().add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, 120, 30));

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setText("UPDATE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        UPDATE.getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 420, 120, 30));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I31.png"))); // NOI18N
        jLabel26.setText("jLabel1");
        UPDATE.getContentPane().add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 490));

        EDIT.setText("EDIT");
        EDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDITActionPerformed(evt);
            }
        });
        jPopupMenu1.add(EDIT);

        update_status.setText("UPDATE OF STATUS");
        update_status.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_statusActionPerformed(evt);
            }
        });
        jPopupMenu1.add(update_status);

        DELETE.setText("DELETE");
        DELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DELETEActionPerformed(evt);
            }
        });
        jPopupMenu1.add(DELETE);

        Status.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(255, 255, 255));
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText("Status of the Blotter");
        Status.getContentPane().add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 320, 30));

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Settled", "Unsettled", "Scheduled", "Unscheduled" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        Status.getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 240, 40));

        update_status_btn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        update_status_btn.setText("UPDATE");
        update_status_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_status_btnActionPerformed(evt);
            }
        });
        Status.getContentPane().add(update_status_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 93, 120, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I3.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        Status.getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 320, 130));

        Contact.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel14.setBackground(new java.awt.Color(0, 102, 153));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 255, 255));
        jLabel54.setText("matthewmejorada10@gmail.com");
        jPanel14.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 280, -1));

        jLabel55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/telephone-removebg-preview.png"))); // NOI18N
        jLabel55.setText("jLabel55");
        jPanel14.add(jLabel55, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 50, 50));

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, 30, 30));

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setText("Developer's Contact");
        jPanel14.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, -1, -1));

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setText("paularyza@gmail.com");
        jPanel14.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, -1, -1));

        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setText("Facebook :");
        jPanel14.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 70, -1, -1));

        jLabel59.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(255, 255, 255));
        jLabel59.setText("Number :");
        jPanel14.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, -1));

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 255, 255));
        jLabel60.setText("Daniel Matthew Mejorada");
        jPanel14.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 190, -1, -1));

        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(255, 255, 255));
        jLabel61.setText("0955-372-4326");
        jPanel14.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, -1));

        jLabel63.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 255, 255));
        jLabel63.setText("0969-562-1730");
        jPanel14.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        jLabel64.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setText("0970-195-9036");
        jPanel14.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(255, 255, 255));
        jLabel65.setText("0994-486-5242");
        jPanel14.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 255, 255));
        jLabel75.setText("melindalinga@gmail.com ");
        jPanel14.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, -1, -1));

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 255, 255));
        jLabel76.setText("Email :");
        jPanel14.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 70, -1, -1));

        jLabel77.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(255, 255, 255));
        jLabel77.setText("viezelmanzano11@gmail.com");
        jPanel14.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, -1, -1));

        jLabel78.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 255, 255));
        jLabel78.setText("Viezel Manzano");
        jPanel14.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 100, -1, -1));

        jLabel79.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(255, 255, 255));
        jLabel79.setText("Paula Ferrera Babaan");
        jPanel14.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 130, -1, -1));

        jLabel80.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(255, 255, 255));
        jLabel80.setText("Melinda Veluz Linga");
        jPanel14.add(jLabel80, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, -1, -1));

        Contact.getContentPane().add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 680, 220));

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I3.png"))); // NOI18N
        jLabel47.setText("jLabel47");
        Contact.getContentPane().add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 260));

        Code.setUndecorated(true);
        Code.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setBackground(new java.awt.Color(102, 204, 255));

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel66.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel66.setText("Enter Your Resign Code to Access");

        jPanel17.setBackground(new java.awt.Color(51, 51, 255));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        X_CODE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        X_CODE.setForeground(new java.awt.Color(255, 255, 255));
        X_CODE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        X_CODE.setText("X");
        X_CODE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                X_CODEMouseClicked(evt);
            }
        });
        jPanel17.add(X_CODE, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 40, 39));

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setText("Enter");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        code_tf.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        code_tf.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        code_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                code_tfActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel66, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(jButton4)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(code_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel66)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(code_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Code.getContentPane().add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 160));

        Help.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 255, 255));
        jLabel69.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel69.setText("Help");
        Help.getContentPane().add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 930, 60));

        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));
        jPanel18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel70.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\annouce_1 (3).png")); // NOI18N
        jLabel70.setText("jLabel70");

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel70, javax.swing.GroupLayout.PREFERRED_SIZE, 905, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel70, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Announcement ", jPanel18);

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel71.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\update_announce (1).png")); // NOI18N
        jLabel71.setText("jLabel70");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel71, javax.swing.GroupLayout.PREFERRED_SIZE, 905, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel71, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Update", jPanel19);

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));
        jPanel20.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel72.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\addpic (1).png")); // NOI18N
        jLabel72.setText("jLabel70");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel72, javax.swing.GroupLayout.PREFERRED_SIZE, 905, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel72, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Add Blotter", jPanel20);

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));

        jLabel81.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\view_1 (1).png")); // NOI18N
        jLabel81.setText("jLabel70");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel81, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel81, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Accessing the View", jPanel21);

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));

        jLabel82.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\view_2 (1).png")); // NOI18N
        jLabel82.setText("jLabel70");

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel82, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel82, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("About View", jPanel22);

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));

        jLabel83.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\view_edit (1).png")); // NOI18N
        jLabel83.setText("jLabel70");

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel83, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel83, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("How to edit Records?", jPanel23);

        jPanel24.setBackground(new java.awt.Color(255, 255, 255));

        jLabel84.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\view_status_1 (1).png")); // NOI18N
        jLabel84.setText("jLabel70");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Updating Status", jPanel24);

        jPanel25.setBackground(new java.awt.Color(255, 255, 255));

        jLabel86.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\view_status (1).png")); // NOI18N
        jLabel86.setText("jLabel70");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel86, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel86, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("About Scheduling", jPanel25);

        jPanel26.setBackground(new java.awt.Color(255, 255, 255));

        jLabel87.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\bar_graph (1).png")); // NOI18N
        jLabel87.setText("jLabel70");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel87, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel87, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("About Statistics", jPanel26);

        jPanel27.setBackground(new java.awt.Color(255, 255, 255));

        jLabel88.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\print (1).png")); // NOI18N
        jLabel88.setText("jLabel70");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel88, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel88, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Print PDF (1)", jPanel27);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel90.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Java Swing\\print_1 (1).png")); // NOI18N
        jLabel90.setText("jLabel70");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel90, javax.swing.GroupLayout.PREFERRED_SIZE, 909, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel90, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Print PDF (2)", jPanel2);

        Help.getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 930, 610));

        jLabel68.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I313.png"))); // NOI18N
        jLabel68.setText("jLabel68");
        Help.getContentPane().add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, 730));

        schedule.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel28.setBackground(new java.awt.Color(204, 204, 255));

        sched_date.setDateFormatString("MMMM dd, yyyy");
        sched_date.setMaxSelectableDate(new java.util.Date(253370739667000L));
        sched_date.setMinSelectableDate(new java.util.Date(-62135794733000L));

        jLabel73.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel73.setText("Date of Scheduled:");

        jLabel74.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel74.setText("Time of Scheduled:");

        sched_time.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        sched_time.setText("00:00");

        update_on_sched.setBackground(new java.awt.Color(102, 102, 255));
        update_on_sched.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        update_on_sched.setText("UPDATE");
        update_on_sched.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_on_schedActionPerformed(evt);
            }
        });

        combo_day.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        combo_day.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AM", "PM" }));

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel74)
                            .addComponent(jLabel73)
                            .addComponent(sched_date, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel28Layout.createSequentialGroup()
                                .addComponent(sched_time, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(combo_day, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel28Layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(update_on_sched, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel73)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(sched_date, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel74)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(combo_day)
                    .addComponent(sched_time, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(update_on_sched, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                .addContainerGap())
        );

        schedule.getContentPane().add(jPanel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 310, 200));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Head_Panel.setBackground(new java.awt.Color(162, 205, 239));

        date.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        date.setForeground(new java.awt.Color(255, 255, 255));
        date.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        date.setText("00/00/00");

        time.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        time.setForeground(new java.awt.Color(255, 255, 255));
        time.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        time.setText(" 0:00:00");

        javax.swing.GroupLayout Head_PanelLayout = new javax.swing.GroupLayout(Head_Panel);
        Head_Panel.setLayout(Head_PanelLayout);
        Head_PanelLayout.setHorizontalGroup(
            Head_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Head_PanelLayout.createSequentialGroup()
                .addContainerGap(914, Short.MAX_VALUE)
                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(200, 200, 200))
            .addGroup(Head_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Head_PanelLayout.createSequentialGroup()
                    .addContainerGap(1176, Short.MAX_VALUE)
                    .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(16, 16, 16)))
        );
        Head_PanelLayout.setVerticalGroup(
            Head_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
            .addGroup(Head_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(time, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
        );

        getContentPane().add(Head_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 40));

        DashBoard_BT.setBackground(new java.awt.Color(0, 102, 153));
        DashBoard_BT.setPreferredSize(new java.awt.Dimension(1330, 710));
        DashBoard_BT.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/logo-removebg-preview.png"))); // NOI18N
        DashBoard_BT.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 230, 180));

        jButton1.setBackground(new java.awt.Color(255, 51, 51));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("Log Out");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        DashBoard_BT.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 470, 230, 40));

        Announce_bt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Announce_bt.setText("Announcement");
        Announce_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Announce_btActionPerformed(evt);
            }
        });
        Announce_bt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                Announce_btKeyPressed(evt);
            }
        });
        DashBoard_BT.add(Announce_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 230, 40));

        Addblotter_bt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Addblotter_bt.setText("Add Blotter");
        Addblotter_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Addblotter_btActionPerformed(evt);
            }
        });
        DashBoard_BT.add(Addblotter_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 230, 40));

        view_bt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        view_bt.setText("View");
        view_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_btActionPerformed(evt);
            }
        });
        DashBoard_BT.add(view_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 230, 40));

        status_bt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        status_bt.setText("Print PDF");
        status_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                status_btActionPerformed(evt);
            }
        });
        DashBoard_BT.add(status_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, 230, 40));

        Update_bt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Update_bt.setText("Update");
        Update_bt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_btActionPerformed(evt);
            }
        });
        Update_bt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                Update_btKeyPressed(evt);
            }
        });
        DashBoard_BT.add(Update_bt, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 270, 230, 40));

        contact1.setBackground(new java.awt.Color(255, 255, 255));
        contact1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        contact1.setForeground(new java.awt.Color(255, 255, 255));
        contact1.setText("Contact the Developers");
        contact1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contact1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                contact1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                contact1MouseExited(evt);
            }
        });
        DashBoard_BT.add(contact1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 710, 160, 20));

        help.setBackground(new java.awt.Color(255, 255, 255));
        help.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        help.setForeground(new java.awt.Color(255, 255, 255));
        help.setText("Help? ");
        help.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                helpMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                helpMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                helpMouseExited(evt);
            }
        });
        DashBoard_BT.add(help, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 650, 50, 20));

        contact.setBackground(new java.awt.Color(255, 255, 255));
        contact.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        contact.setForeground(new java.awt.Color(255, 255, 255));
        contact.setText("Have a Problem?");
        contact.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contactMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                contactMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                contactMouseExited(evt);
            }
        });
        DashBoard_BT.add(contact, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 690, 120, 20));

        username_homepage.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        username_homepage.setForeground(new java.awt.Color(255, 255, 255));
        username_homepage.setText("name");
        DashBoard_BT.add(username_homepage, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 120, 40));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Username:");
        DashBoard_BT.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 90, 40));

        getContentPane().add(DashBoard_BT, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 230, 760));

        Dashboard_PL.setLayout(new javax.swing.OverlayLayout(Dashboard_PL));

        announce_pl.setPreferredSize(new java.awt.Dimension(1140, 750));
        announce_pl.setVerifyInputWhenFocusTarget(false);
        announce_pl.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 48)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("ANNOUNCEMENT");
        announce_pl.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 110));

        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        IMAGE_SHARE.setIcon(new javax.swing.ImageIcon("C:\\Users\\jcram\\Desktop\\Barangay.jpg")); // NOI18N
        IMAGE_SHARE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.add(IMAGE_SHARE, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 550, 310));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 30)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 1000, 1040, 40));

        jScrollPane6.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        WhatsNew.setEditable(false);
        WhatsNew.setBackground(new java.awt.Color(0, 102, 153));
        WhatsNew.setColumns(20);
        WhatsNew.setFont(new java.awt.Font("Times New Roman", 0, 25)); // NOI18N
        WhatsNew.setForeground(new java.awt.Color(255, 255, 255));
        WhatsNew.setRows(5);
        jScrollPane6.setViewportView(WhatsNew);

        jPanel3.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 410, 950, 470));

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 30)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel17.setText("What's New");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 340, 950, 60));

        today_sched.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Today's Schedule"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane15.setViewportView(today_sched);

        jPanel3.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 10, 440, 310));

        jScrollPane4.setViewportView(jPanel3);

        announce_pl.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 1120, 650));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I313.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        announce_pl.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 750));

        Dashboard_PL.add(announce_pl);

        update_pl.setPreferredSize(new java.awt.Dimension(1140, 750));
        update_pl.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        IMG4.setBackground(new java.awt.Color(204, 204, 255));
        IMG4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        IMG4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(IMG4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 240, 150));

        IMG5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        IMG5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(IMG5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 240, 150));

        IMG6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        IMG6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(IMG6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 240, 150));

        UploadIMG1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        UploadIMG1.setText("Update Photo");
        UploadIMG1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UploadIMG1ActionPerformed(evt);
            }
        });
        jPanel1.add(UploadIMG1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 130, 40));

        UploadIMG2.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        UploadIMG2.setText("Update Photo");
        UploadIMG2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UploadIMG2ActionPerformed(evt);
            }
        });
        jPanel1.add(UploadIMG2, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 250, 130, 40));

        UpdateText.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        UpdateText.setText("Update Announcement");
        UpdateText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateTextActionPerformed(evt);
            }
        });
        jPanel1.add(UpdateText, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 540, 200, 40));

        jScrollPane7.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        WhatsNew1.setColumns(20);
        WhatsNew1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        WhatsNew1.setRows(5);
        jScrollPane7.setViewportView(WhatsNew1);

        jPanel1.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, 650, 510));

        UploadIMG3.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        UploadIMG3.setText("Update Photo");
        UploadIMG3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UploadIMG3ActionPerformed(evt);
            }
        });
        jPanel1.add(UploadIMG3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 420, 130, 40));

        jPanel29.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 240, 150));

        jPanel30.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 240, 150));

        jPanel31.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 240, 150));

        update_pl.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 1090, 640));

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 1, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("UPDATE OF ANNOUNCEMENTS");
        update_pl.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 110));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I313.png"))); // NOI18N
        jLabel10.setText("jLabel10");
        update_pl.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1450, 750));

        Dashboard_PL.add(update_pl);
        update_pl.getAccessibleContext().setAccessibleName("");

        addblotter_pl.setPreferredSize(new java.awt.Dimension(1140, 750));
        addblotter_pl.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(0, 102, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel5.setText("Case Number:");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 39));

        case1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        case1.setForeground(new java.awt.Color(255, 255, 255));
        case1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        case1.setText("100");
        jPanel4.add(case1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 10, 50, 39));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel14.setText("Report:");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 40));

        report_ta.setColumns(20);
        report_ta.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        report_ta.setRows(5);
        jScrollPane1.setViewportView(report_ta);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 250));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setText("Location:");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, 40));

        location_ta.setColumns(20);
        location_ta.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        location_ta.setRows(5);
        jScrollPane2.setViewportView(location_ta);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, -1, 210));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel19.setText("Name of Complainant:");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 14, -1, -1));

        name_complainant.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel4.add(name_complainant, new org.netbeans.lib.awtextra.AbsoluteConstraints(624, 6, 440, 42));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel20.setText("Address of Complainant:");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 76, -1, 39));

        address_complainant.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel4.add(address_complainant, new org.netbeans.lib.awtextra.AbsoluteConstraints(624, 75, 440, 42));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel21.setText("Name of Accused:");
        jPanel4.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 152, -1, 38));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel22.setText("Detailed Report:");
        jPanel4.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 286, -1, 38));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel23.setText("Address of Accused:");
        jPanel4.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 219, -1, 38));

        name_accuse.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel4.add(name_accuse, new org.netbeans.lib.awtextra.AbsoluteConstraints(624, 151, 440, 42));

        address_accuse.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jPanel4.add(address_accuse, new org.netbeans.lib.awtextra.AbsoluteConstraints(624, 218, 440, 42));

        detailed_report_ta.setColumns(20);
        detailed_report_ta.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        detailed_report_ta.setRows(5);
        jScrollPane5.setViewportView(detailed_report_ta);

        jPanel4.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(391, 330, 670, 290));

        add_btn.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        add_btn.setText("Add");
        add_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_btnActionPerformed(evt);
            }
        });
        jPanel4.add(add_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 640, 187, 43));

        addblotter_pl.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 1100, 700));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I313.png"))); // NOI18N
        jLabel11.setText("jLabel11");
        jLabel11.setPreferredSize(new java.awt.Dimension(1140, 750));
        addblotter_pl.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 750));

        Dashboard_PL.add(addblotter_pl);

        view_pl.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(0, 102, 153));
        jPanel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel10.setBackground(new java.awt.Color(51, 204, 0));

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("Settled");
        jLabel39.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        set.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        set.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        set.setText("0");
        set.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel39, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addComponent(set, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel39)
                .addGap(37, 37, 37)
                .addComponent(set)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jPanel9.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 210, 160));

        jPanel11.setBackground(new java.awt.Color(255, 51, 51));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel42.setText("Unsettled");
        jLabel42.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        unset.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        unset.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        unset.setText("0");
        unset.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel42, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(unset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel42)
                .addGap(33, 33, 33)
                .addComponent(unset)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        jPanel9.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 210, 160));

        jPanel12.setBackground(new java.awt.Color(255, 255, 51));

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setText("Scheduled");
        jLabel41.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        sched.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        sched.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        sched.setText("0");
        sched.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(sched, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jLabel41)
                .addGap(43, 43, 43)
                .addComponent(sched)
                .addGap(0, 60, Short.MAX_VALUE))
        );

        jPanel9.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, 210, 160));

        jPanel13.setBackground(new java.awt.Color(255, 153, 0));

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setText("Unscheduled");
        jLabel43.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        unsched.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        unsched.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        unsched.setText("0");
        unsched.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel43, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
            .addComponent(unsched, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jLabel43)
                .addGap(39, 39, 39)
                .addComponent(unsched)
                .addGap(0, 64, Short.MAX_VALUE))
        );

        jPanel9.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 50, 210, -1));

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("Status of Blotter Records");
        jLabel40.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel9.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(8, 8, 1104, -1));

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton3.setText("View Statistics");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel9.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(475, 220, 160, 30));

        view_pl.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 1120, 260));

        jPanel5.setBackground(new java.awt.Color(0, 102, 153));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/images-removebg-preview.png"))); // NOI18N
        jLabel25.setText("jLabel24");
        jPanel5.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 50, 40));

        searchbar_tf.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchbar_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbar_tfActionPerformed(evt);
            }
        });
        searchbar_tf.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                searchbar_tfPropertyChange(evt);
            }
        });
        searchbar_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchbar_tfKeyReleased(evt);
            }
        });
        jPanel5.add(searchbar_tf, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 600, 40));

        blotters_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Case No#", "Date", "Time", "Report", "Location", "Name Of Complainant", "Address Of Complainant", "Name Of Accused", "Address Of Accused", "Detailed Report", "Status", "Schedule", "Name of User"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        blotters_table.setComponentPopupMenu(jPopupMenu1);
        blotters_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                blotters_tableMouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(blotters_table);

        jPanel5.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1080, 300));

        view_pl.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1120, 440));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I313.png"))); // NOI18N
        view_pl.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1140, 740));

        Dashboard_PL.add(view_pl);

        status_pl.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(0, 102, 153));
        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel44.setFont(new java.awt.Font("Tahoma", 0, 35)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(255, 255, 255));
        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setText("Print Documents");
        jPanel6.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1090, 60));

        jLabel45.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/images-removebg-preview.png"))); // NOI18N
        jLabel45.setText("jLabel24");
        jPanel6.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 50, 40));

        searchbar_tf1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        searchbar_tf1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbar_tf1ActionPerformed(evt);
            }
        });
        searchbar_tf1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                searchbar_tf1PropertyChange(evt);
            }
        });
        searchbar_tf1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchbar_tf1KeyReleased(evt);
            }
        });
        jPanel6.add(searchbar_tf1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 470, 40));

        blotters_table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Case No#", "Date", "Time", "Report", "Location", "Name Of Complainant", "Address Of Complainant", "Name Of Accused", "Address Of Accused", "Detailed Report"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        blotters_table1.setComponentPopupMenu(jPopupMenu1);
        blotters_table1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                blotters_table1MouseClicked(evt);
            }
        });
        jScrollPane13.setViewportView(blotters_table1);

        jPanel6.add(jScrollPane13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 540, 510));

        jScrollPane14.setBackground(new java.awt.Color(255, 255, 255));

        PrintPanel.setBackground(new java.awt.Color(255, 255, 255));
        PrintPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PrintPanel.setMinimumSize(new java.awt.Dimension(510, 520));
        PrintPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/logo21.png"))); // NOI18N
        PrintPanel.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 90, 90));

        jLabel48.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel48.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel48.setText("Republika ng Pilipinas");
        PrintPanel.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 340, 30));

        jLabel49.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel49.setText("Lalawigan ng Laguna");
        PrintPanel.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 340, 30));

        jLabel50.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel50.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel50.setText("BARANGAY  PINAGSANJAN");
        PrintPanel.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 340, 30));

        jLabel51.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel51.setText("SUMMON");
        PrintPanel.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 490, 30));

        jLabel52.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel52.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel52.setText("_______________________________________________________________________________________");
        PrintPanel.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 530, 30));

        jLabel85.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        PrintPanel.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 730, 500, 30));

        jLabel89.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel89.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel89.setText("Bayan ng Pagsanjan");
        PrintPanel.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 340, 30));

        sched_time_today.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        sched_time_today.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        sched_time_today.setText("*****");
        PrintPanel.add(sched_time_today, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 380, 50, 30));

        jLabel95.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel95.setText("FOR:");
        PrintPanel.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, 30, 30));

        reportname.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        reportname.setText("*****");
        PrintPanel.add(reportname, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 180, 210, 30));

        jLabel99.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel99.setText("CASE NO # ENTRY:");
        PrintPanel.add(jLabel99, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 140, 110, 30));

        casename.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        casename.setText("*****");
        PrintPanel.add(casename, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 140, 60, 30));

        jLabel103.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel103.setText("TO:");
        PrintPanel.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 30, 30));

        comname.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        comname.setText("*****");
        PrintPanel.add(comname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 260, 30));

        jLabel106.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel106.setText("--against--");
        PrintPanel.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 100, 30));

        jLabel108.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel108.setText("Julius Natividad Guan ");
        PrintPanel.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 630, 130, 30));

        accname.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        accname.setText("*****");
        PrintPanel.add(accname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 250, 30));

        jLabel109.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel109.setText("This ");
        PrintPanel.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, 40, 30));

        jLabel113.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel113.setText("______________________");
        PrintPanel.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 630, 140, 30));

        jLabel107.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel107.setText("COMPLAINANT:");
        PrintPanel.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 100, 30));

        jLabel62.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel62.setText("OFFICE OF THE BARANGAY PINAGSANJAN");
        PrintPanel.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 520, 30));

        comname1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        comname1.setText("*****");
        PrintPanel.add(comname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 330, 30));

        jLabel105.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel105.setText("RESPONDENT:");
        PrintPanel.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 200, 30));

        jLabel116.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel116.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel116.setText("You are hereby summonded to appear before me in person, together with your witnesses on the");
        PrintPanel.add(jLabel116, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 500, 30));

        jLabel117.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel117.setText("o'clock, then");
        PrintPanel.add(jLabel117, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 380, 90, 30));

        jLabel118.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel118.setText("answer to a complainant made before me, copy of which is attach hereto, for mediation");
        PrintPanel.add(jLabel118, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, 30));

        jLabel119.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel119.setText("conciliation of your dispute with complainant.");
        PrintPanel.add(jLabel119, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, 500, 30));

        jLabel120.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel120.setText("You are hereby,warned that if you refuse or willfully fail to appear in obedience to this ");
        PrintPanel.add(jLabel120, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, 500, 30));

        jLabel121.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel121.setText("summons, you may be barred from filling any counterclaim arising from said complainant.");
        PrintPanel.add(jLabel121, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 500, 30));

        jLabel122.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel122.setText("                 or else face punishment as for contempt of court.");
        PrintPanel.add(jLabel122, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 500, 30));

        jLabel94.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel94.setForeground(new java.awt.Color(204, 0, 0));
        jLabel94.setText("FAIL NOT ");
        PrintPanel.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, 60, 30));

        jLabel96.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel96.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel96.setText("Barangay Chairman");
        PrintPanel.add(jLabel96, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 650, 140, 30));

        date_today1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        date_today1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        date_today1.setText("*****");
        PrintPanel.add(date_today1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 510, 80, 30));

        sched_date_today1.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        sched_date_today1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        sched_date_today1.setText("*****");
        PrintPanel.add(sched_date_today1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, 100, 30));

        jLabel123.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jLabel123.setText(",");
        PrintPanel.add(jLabel123, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 380, 20, 30));

        jScrollPane14.setViewportView(PrintPanel);
        PrintPanel.getAccessibleContext().setAccessibleParent(jScrollPane14);

        jPanel6.add(jScrollPane14, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 70, 550, 740));

        Print.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        Print.setText("Print");
        Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintActionPerformed(evt);
            }
        });
        jPanel6.add(Print, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 660, 160, 40));

        status_pl.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 1120, 710));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/blottersystem/I313.png"))); // NOI18N
        jLabel8.setText("jLabel8");
        jLabel8.setPreferredSize(new java.awt.Dimension(1140, 750));
        status_pl.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 730));

        Dashboard_PL.add(status_pl);

        getContentPane().add(Dashboard_PL, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 40, 1140, 750));
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to Log Out?", "Logging Out Confirmation", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            Login login = new Login();
            login.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void view_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_btActionPerformed
        Code.setVisible(true);
        Code.setSize(310,160);
        Code.setLocationRelativeTo(this);
    }//GEN-LAST:event_view_btActionPerformed

    private void status_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_status_btActionPerformed
        status_bt.setBackground(new Color(0, 102, 204));
        Update_bt.setBackground(new Color(240, 240, 240));
        Addblotter_bt.setBackground(new Color(240, 240, 240));
        view_bt.setBackground(new Color(240, 240, 240));
        Announce_bt.setBackground(new Color(240, 240, 240));

        status_pl.setVisible(true);
        update_pl.setVisible(false);
        addblotter_pl.setVisible(false);
        view_pl.setVisible(false);
        announce_pl.setVisible(false);
        BlotterTable1();
      
    }//GEN-LAST:event_status_btActionPerformed

    private void Update_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_btActionPerformed
        Update_bt.setBackground(new Color(0, 102, 204));
        Announce_bt.setBackground(new Color(240, 240, 240));
        Addblotter_bt.setBackground(new Color(240, 240, 240));
        view_bt.setBackground(new Color(240, 240, 240));
        status_bt.setBackground(new Color(240, 240, 240));

        update_pl.setVisible(true);
        announce_pl.setVisible(false);
        addblotter_pl.setVisible(false);
        view_pl.setVisible(false);
        status_pl.setVisible(false);
       
        
         showImageAndWhatsNew();
    }//GEN-LAST:event_Update_btActionPerformed

    private void Announce_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Announce_btActionPerformed
        Announce_bt.setBackground(new Color(0, 102, 204));
        Update_bt.setBackground(new Color(240, 240, 240));
        Addblotter_bt.setBackground(new Color(240, 240, 240));
        view_bt.setBackground(new Color(240, 240, 240));
        status_bt.setBackground(new Color(240, 240, 240));

        announce_pl.setVisible(true);
        update_pl.setVisible(false);
        addblotter_pl.setVisible(false);
        view_pl.setVisible(false);
        status_pl.setVisible(false);
        loadImages();
         TODAY();
         showImageAndWhatsNew();



      
    }//GEN-LAST:event_Announce_btActionPerformed

    private void Addblotter_btActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Addblotter_btActionPerformed
       Addblotter_bt.setBackground(new Color(0, 102, 204));
        Update_bt.setBackground(new Color(240, 240, 240));
        Announce_bt.setBackground(new Color(240, 240, 240));
        view_bt.setBackground(new Color(240, 240, 240));
        status_bt.setBackground(new Color(240, 240, 240));

        addblotter_pl.setVisible(true);
        update_pl.setVisible(false);
        announce_pl.setVisible(false);
        view_pl.setVisible(false);
        status_pl.setVisible(false);
        
          CaseNumber();
    }//GEN-LAST:event_Addblotter_btActionPerformed

    private void UploadIMG1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UploadIMG1ActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image", "jpeg", "png");
        fileChooser.addChoosableFileFilter(filter);
        fileChooser.setDialogTitle("Upload Image");

        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedImage = fileChooser.getSelectedFile();
            String imagePath = selectedImage.getAbsolutePath();
            try {
                IMG4.setIcon(ResizeImage1(imagePath));
                imagePathStr = imagePath;

                PreparedStatement pst = conn.prepareStatement("UPDATE settings SET Image1 = ? WHERE IDNo = '1'");

                InputStream inputStream = new FileInputStream(new File(imagePathStr));
                pst.setBlob(1, inputStream);

                pst.execute();

                JOptionPane.showMessageDialog(this, "Photo Uploaded", "Success", JOptionPane.INFORMATION_MESSAGE);

                imagePathStr = "";
                showImageAndWhatsNew();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Image Error: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_UploadIMG1ActionPerformed

    private void UploadIMG2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UploadIMG2ActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image", "jpeg", "png");
        fileChooser.addChoosableFileFilter(filter);
        fileChooser.setDialogTitle("Upload Image");

        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedImage = fileChooser.getSelectedFile();
            String imagePath = selectedImage.getAbsolutePath();
            try {
                IMG5.setIcon(ResizeImage2(imagePath));
                imagePathStr = imagePath;

                PreparedStatement pst = conn.prepareStatement("UPDATE settings SET Image2 = ? WHERE IDNo = '1'");

                InputStream inputStream = new FileInputStream(new File(imagePathStr));
                pst.setBlob(1, inputStream);

                pst.execute();

                JOptionPane.showMessageDialog(this, "Photo Uploaded", "Success", JOptionPane.INFORMATION_MESSAGE);

                imagePathStr = "";
                showImageAndWhatsNew();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Image Error: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_UploadIMG2ActionPerformed

    private void UpdateTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateTextActionPerformed
        try {
            String sql = "UPDATE settings SET Announce = ? WHERE IDNo = '1'";
            pst = conn.prepareStatement(sql);

            pst.setString(1, WhatsNew1.getText());
            pst.execute();

            JOptionPane.showMessageDialog(this, "Updated Announcement", "Success", JOptionPane.INFORMATION_MESSAGE);

            showImageAndWhatsNew();

        } catch (Exception e) {

        }
    }//GEN-LAST:event_UpdateTextActionPerformed

    private void UploadIMG3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UploadIMG3ActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image", "jpeg", "png");
        fileChooser.addChoosableFileFilter(filter);
        fileChooser.setDialogTitle("Upload Image");

        int result = fileChooser.showSaveDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedImage = fileChooser.getSelectedFile();
            String imagePath = selectedImage.getAbsolutePath();
            try {
                IMG6.setIcon(ResizeImage3(imagePath));
                imagePathStr = imagePath;

                PreparedStatement pst = conn.prepareStatement("UPDATE settings SET Image3 = ? WHERE IDNo = '1'");

                InputStream inputStream = new FileInputStream(new File(imagePathStr));
                pst.setBlob(1, inputStream);

                pst.execute();

                JOptionPane.showMessageDialog(this, "Photo Uploaded", "Success", JOptionPane.INFORMATION_MESSAGE);

                imagePathStr = "";
//                showImageAndWhatsNew();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Image Error: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_UploadIMG3ActionPerformed

    private void add_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_btnActionPerformed
        String status = "Unscheduled";
        String d = "";
        String t = "";
        if("".equals(report_ta.getText()) || "".equals(location_ta.getText()) || "".equals(name_complainant.getText()) || "".equals(address_complainant.getText())
                   || "".equals(name_accuse.getText()) || "".equals(address_accuse.getText()) || "".equals(detailed_report_ta.getText())){
                JOptionPane.showMessageDialog(null,"Please Complete the Informtion");
                
            }else{
        try {
          PreparedStatement pst = conn.prepareStatement("INSERT INTO addblotter(name_of_username,case_blotter, date_blotter, time_blotter, report_blotter, location_blotter, complainant_blotter, address_complainant, accused_blotter, address_accused, detailed_report,status_blotter,date_status,time_status) "
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
          
            pst.setString(1, username_homepage.getText());
            pst.setString(2, case1.getText());
            pst.setString(3, date.getText());
            pst.setString(4, time.getText());
            pst.setString(5, report_ta.getText());
            pst.setString(6, location_ta.getText());
            pst.setString(7, name_complainant.getText());
            pst.setString(8, address_complainant.getText());
            pst.setString(9, name_accuse.getText());
            pst.setString(10, address_accuse.getText());
            pst.setString(11, detailed_report_ta.getText());
            pst.setString(12, status);
            pst.setString(13, d);
            pst.setString(14, t);
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Record Added", "Success", JOptionPane.INFORMATION_MESSAGE);
        
            int num = Integer.parseInt(case1.getText());
            ++num;
            case1.setText(Integer.toString(num));
            report_ta.setText("");
            location_ta.setText("");
            name_complainant.setText("");
            address_complainant.setText("");
            name_accuse.setText("");
            address_accuse.setText("");
            detailed_report_ta.setText("");
             
            
        } catch (Exception e) {
             Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
        }
        }
    }//GEN-LAST:event_add_btnActionPerformed

    private void Announce_btKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Announce_btKeyPressed
   
    }//GEN-LAST:event_Announce_btKeyPressed

    private void Update_btKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Update_btKeyPressed

    }//GEN-LAST:event_Update_btKeyPressed

    private void searchbar_tfPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_searchbar_tfPropertyChange
       
    }//GEN-LAST:event_searchbar_tfPropertyChange

    private void searchbar_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbar_tfActionPerformed
        
    }//GEN-LAST:event_searchbar_tfActionPerformed

    private void searchbar_tfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchbar_tfKeyReleased
         String search = searchbar_tf.getText();
        try {
            pst = conn.prepareStatement("SELECT * FROM addblotter WHERE case_blotter LIKE '%" + search + "%' OR date_blotter LIKE '%"+ search +"%'"
                    + "OR time_blotter LIKE '%"+ search +"%' OR report_blotter LIKE '%"+ search +"%' OR location_blotter LIKE '%"+ search +"%'"
                    + "OR complainant_blotter LIKE '%"+ search +"%' OR address_complainant LIKE '%"+ search +"%'"
                    + "OR accused_blotter LIKE '%"+ search +"%' OR address_accused LIKE '%"+ search +"%' OR detailed_report LIKE '%"+ search +"%'"
                            + "OR name_of_username LIKE '%"+ search +"%' OR status_blotter LIKE '%"+ search +"%' OR date_status LIKE '%"+ search +"%' OR time_status LIKE '%"+ search +"%'");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) blotters_table.getModel();
            model.setRowCount(0);
            while(rs.next()){
              model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)
              , rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14)});
            }

        } catch (Exception e) {

        }
    }//GEN-LAST:event_searchbar_tfKeyReleased

    private void EDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDITActionPerformed
        try {
             int row = blotters_table.getSelectedRow();
            String tableclicked = (blotters_table.getModel().getValueAt(row, 0).toString());
        String sql = "SELECT * FROM addblotter WHERE case_blotter = '"+tableclicked+"'";
            pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
            String num1 = rs.getString("case_blotter");
                String rep1 = rs.getString("report_blotter");
                String loc1 = rs.getString("location_blotter");
                String com1 = rs.getString("complainant_blotter");
                String addcom1 = rs.getString("address_complainant");
                String acc1 = rs.getString("accused_blotter");
                String addacc1 = rs.getString("address_accused");
                String detail1 = rs.getString("detailed_report");

                case_num.setText(num1);
                loc_edit.setText(loc1);
                name_com_edit.setText(com1);
                add_com_edit.setText(addcom1);
                report_edit.setText(rep1);
                name_acc_edit.setText(acc1);
                add_acc_edit.setText(addacc1);
                detail_edit.setText(detail1);
                
            }
          UPDATE.setVisible(true);   
          UPDATE.setSize(730,530);
          UPDATE.setLocationRelativeTo(null);
          
        } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
        }
    }//GEN-LAST:event_EDITActionPerformed

    private void blotters_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_blotters_tableMouseClicked

    }//GEN-LAST:event_blotters_tableMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        updateAccount();        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void DELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETEActionPerformed
        try {
            int row = blotters_table.getSelectedRow();
            String idno = (blotters_table.getModel().getValueAt(row, 0).toString());

            int x = JOptionPane.showConfirmDialog(this, "Are you sure you want to Delete This Information ?");

            if (x == 0) {
                pst = conn.prepareStatement("DELETE FROM addblotter WHERE case_blotter = ?");
                pst.setString(1, idno);
                pst.execute();

                deleteBrgyInfo();

                JOptionPane.showMessageDialog(this, "Successfully Delete!", "Success", JOptionPane.INFORMATION_MESSAGE);

                BlotterTable();
            }
        } catch (Exception e) {

        }
    }//GEN-LAST:event_DELETEActionPerformed

    private void helpMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_helpMouseEntered
       help.setText("<html><u>Help?</u></html>");
    }//GEN-LAST:event_helpMouseEntered

    private void helpMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_helpMouseExited
        help.setText("<html>Help?</html>");
    }//GEN-LAST:event_helpMouseExited

    private void contactMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contactMouseEntered
        contact.setText("<html><u>Have a Problem?</u></html>");
        contact1.setText("<html><u>Contact the Developers</u></html>");
    }//GEN-LAST:event_contactMouseEntered

    private void contactMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contactMouseExited
         contact.setText("<html>Have a Problem?</html>");
         contact1.setText("<html>Contact the Developers</html>");
    }//GEN-LAST:event_contactMouseExited

    private void contact1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact1MouseEntered
         contact.setText("<html><u>Have a Problem?</u></html>");
        contact1.setText("<html><u>Contact the Developers</u></html>");
    }//GEN-LAST:event_contact1MouseEntered

    private void contact1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact1MouseExited
          contact.setText("<html>Have a Problem?</html>");
         contact1.setText("<html>Contact the Developers</html>");
    }//GEN-LAST:event_contact1MouseExited

    private void searchbar_tf1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbar_tf1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchbar_tf1ActionPerformed

    private void searchbar_tf1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_searchbar_tf1PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_searchbar_tf1PropertyChange

    private void searchbar_tf1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchbar_tf1KeyReleased
        String search = searchbar_tf1.getText();
        try {
            pst = conn.prepareStatement("SELECT * FROM addblotter WHERE case_blotter LIKE '%" + search + "%' OR date_blotter LIKE '%"+ search +"%'"
                    + "OR time_blotter LIKE '%"+ search +"%' OR report_blotter LIKE '%"+ search +"%' OR location_blotter LIKE '%"+ search +"%'"
                    + "OR complainant_blotter LIKE '%"+ search +"%' OR address_complainant LIKE '%"+ search +"%'"
                    + "OR accused_blotter LIKE '%"+ search +"%' OR address_accused LIKE '%"+ search +"%' OR detailed_report LIKE '%"+ search +"%'"
                            + "OR name_of_username LIKE '%"+ search +"%' OR status_blotter LIKE '%"+ search +"%' OR date_status LIKE '%"+ search +"%' OR time_status LIKE '%"+ search +"%'");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) blotters_table1.getModel();
            model.setRowCount(0);
            while(rs.next()){
              model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)
              , rs.getString(11), rs.getString(12), rs.getString(13), rs.getString(14)});
            }

        } catch (Exception e) {

        }
    }//GEN-LAST:event_searchbar_tf1KeyReleased

    private void blotters_table1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_blotters_table1MouseClicked
      try {
            int row = blotters_table1.getSelectedRow();
            String idno = (blotters_table1.getModel().getValueAt(row, 0).toString());

            String sql = "SELECT case_blotter, report_blotter, complainant_blotter,accused_blotter,date_status,time_status FROM addblotter WHERE case_blotter = '" + idno + "'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            if (rs.next()) {


                String case11 = rs.getString("case_blotter");
                String report = rs.getString("report_blotter");
                String com1 = rs.getString("complainant_blotter");
                String acc1 = rs.getString("accused_blotter");
                String d = rs.getString("date_status");
                String ttime = rs.getString("time_status");

                casename.setText(case11);
                reportname.setText(report.toUpperCase());
                comname.setText(com1.toUpperCase());
                comname1.setText(com1.toUpperCase());
                accname.setText(acc1.toUpperCase());
                date_today1.setText(date.getText());
                sched_date_today1.setText(d.toUpperCase());
                sched_time_today.setText(ttime.toUpperCase());

            }

//            showImage();
        } catch (Exception e) {

        }
    }//GEN-LAST:event_blotters_table1MouseClicked

    private void PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintActionPerformed
         printField(PrintPanel);
    }//GEN-LAST:event_PrintActionPerformed

    private void update_statusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_statusActionPerformed
          Status.setVisible(true); 
          Status.setSize(320,169);
          Status.pack();
          Status.setLocationRelativeTo(this); 
    }//GEN-LAST:event_update_statusActionPerformed

    private void update_status_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_status_btnActionPerformed
        try {
             int row = blotters_table.getSelectedRow();
            String tableclicked = (blotters_table.getModel().getValueAt(row, 0).toString());
     PreparedStatement pst = conn.prepareStatement("UPDATE addblotter SET status_blotter= ? WHERE case_blotter ='" + tableclicked + "'");
          
            pst.setString(1, jComboBox1.getSelectedItem().toString());
            pst.executeUpdate();
          JOptionPane.showMessageDialog(this, "Updated Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

          BlotterTable();
           status_label();
           status_label1();
           status_label2();
           status_label3();
           jComboBox1.setSelectedIndex(0);
          Status.dispose();
          
        } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
        }
    }//GEN-LAST:event_update_status_btnActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
 String sql  = "SELECT \n" +
"    CASE\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'January' THEN 1\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'February' THEN 2\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'March' THEN 3\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'April' THEN 4\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'May' THEN 5\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'June' THEN 6\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'July' THEN 7\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'August' THEN 8\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'September' THEN 9\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'October' THEN 10\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'November' THEN 11\n" +
"        WHEN SUBSTRING_INDEX(`date_blotter`, '-', 1) = 'December' THEN 12\n" +
"        ELSE 0\n" +
"    END AS month_num,\n" +
"    SUM(CASE WHEN status_blotter = 'Settled' THEN 1 ELSE 0 END) AS settled_count,\n" +
"    SUM(CASE WHEN status_blotter = 'Unsettled' THEN 1 ELSE 0 END) AS unsettled_count\n" +
"FROM addblotter \n" +
"GROUP BY month_num \n" +
"ORDER BY month_num;";
try {
    pst = conn.prepareStatement(sql);
    rs = pst.executeQuery();

    DefaultCategoryDataset dataset = new DefaultCategoryDataset();

    while (rs.next()) {
        int monthNum = rs.getInt("month_num");
        int settledCount = rs.getInt("settled_count");
        int unsettledCount = rs.getInt("unsettled_count");

        String month = getMonthName(monthNum);

        dataset.addValue(settledCount, "Settled", month);
        dataset.addValue(unsettledCount, "Unsettled", month);
    }

    JFreeChart chart = ChartFactory.createBarChart(
            "Statistics Of Blotter 2024",
            "Months",
            "Number of People's Blotter",
            dataset,
            PlotOrientation.VERTICAL,
            true,
            true,
            false);

    CategoryPlot plot = chart.getCategoryPlot();
    BarRenderer renderer = (BarRenderer) plot.getRenderer();
    renderer.setSeriesPaint(0, Color.GREEN); // Settled
    renderer.setSeriesPaint(1, Color.RED);  // Unsettled

    // Create legend items for Settled and Unsettled
    LegendItem item1 = new LegendItem("Settled", null, null, null, Plot.DEFAULT_LEGEND_ITEM_BOX, Color.BLUE);
    LegendItem item2 = new LegendItem("Unsettled", null, null, null, Plot.DEFAULT_LEGEND_ITEM_BOX, Color.RED);
    LegendItemCollection legendItems = new LegendItemCollection();
    legendItems.add(item1);
    legendItems.add(item2);

    // Add legend to the chart
    plot.setFixedLegendItems(legendItems);

    JFrame frame = new JFrame("Statistics");
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    ChartPanel chartPanel = new ChartPanel(chart);
    frame.add(chartPanel);
    frame.pack();
    frame.setLocationRelativeTo(this);

    frame.setVisible(true);
} catch (Exception e) {
    Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
}
    }//GEN-LAST:event_jButton3ActionPerformed

    private void contactMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contactMouseClicked
       Contact.setVisible(true);
       Contact.setSize(600,295);
       Contact.pack();
       Contact.setLocationRelativeTo(this);
    }//GEN-LAST:event_contactMouseClicked

    private void contact1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contact1MouseClicked
       Contact.setVisible(true);
       Contact.setSize(600,295);
       Contact.pack();
       Contact.setLocationRelativeTo(this);
    }//GEN-LAST:event_contact1MouseClicked

    private void X_CODEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_X_CODEMouseClicked
        Code.dispose();
        Announce_bt.setBackground(new Color(0, 102, 204));
        Update_bt.setBackground(new Color(240, 240, 240));
        Addblotter_bt.setBackground(new Color(240, 240, 240));
        view_bt.setBackground(new Color(240, 240, 240));
        status_bt.setBackground(new Color(240, 240, 240));

        announce_pl.setVisible(true);
        update_pl.setVisible(false);
        addblotter_pl.setVisible(false);
        view_pl.setVisible(false);
        status_pl.setVisible(false);
       
        
            showImageAndWhatsNew();
      
    }//GEN-LAST:event_X_CODEMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
          String name_user = username_homepage.getText();
          String code = code_tf.getText();
        String sql = "SELECT * FROM accounts WHERE Username = '"+name_user+"'";
        try {
            pst = conn.prepareStatement(sql);
             rs = pst.executeQuery();
            if(rs.next()){
                String accUsername = rs.getString("Username");
                String num = rs.getString("SELF_CODE");
            
            
        if(name_user.equals(accUsername) && code.equals(num)){
        Code.dispose();
        code_tf.setText("");
        view_bt.setBackground(new Color(0, 102, 204));
        Update_bt.setBackground(new Color(240, 240, 240));
        Addblotter_bt.setBackground(new Color(240, 240, 240));
        Announce_bt.setBackground(new Color(240, 240, 240));
        status_bt.setBackground(new Color(240, 240, 240));

        view_pl.setVisible(true);
        update_pl.setVisible(false);
        addblotter_pl.setVisible(false);
        announce_pl.setVisible(false);
        status_pl.setVisible(false);
        CaseNumber();
        BlotterTable();
        status_label();
        status_label1();
        status_label2();
        status_label3();
        }else{
        JOptionPane.showMessageDialog(null,"Wrong Code");
        Code.dispose();
        code_tf.setText("");
        
         showImageAndWhatsNew();
             }
            }
            
        } catch (Exception e) {
              Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void helpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_helpMouseClicked
       Help.setVisible(true);
       Help.setSize(1539, 834);
       Help.pack();
       Help.setLocationRelativeTo(null);
    }//GEN-LAST:event_helpMouseClicked

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
          String selectedItem = (String) jComboBox1.getSelectedItem();
                
                if ("Scheduled".equals(selectedItem)) {
                    schedule.setVisible(true);
                    schedule.setSize(1539, 834);
                    schedule.pack();
                    schedule.setLocationRelativeTo(null);
                }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void update_on_schedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_on_schedActionPerformed
   String s = sched_time.getText().trim();
   Date selectedDate = sched_date.getDate();
            String c = combo_day.getSelectedItem().toString().trim();
            String sc = s+" "+c;
        try {
             int row = blotters_table.getSelectedRow();
            String tableclicked = (blotters_table.getModel().getValueAt(row, 0).toString());
     PreparedStatement pst = conn.prepareStatement("UPDATE addblotter SET status_blotter = ?,date_status = ?, time_status= ? WHERE case_blotter ='" + tableclicked + "'");
            if(selectedDate == null || s.isEmpty()){
          JOptionPane.showMessageDialog(null,"Please put a time and date schedule !");
          return;
            }else{
            SimpleDateFormat dateFormat = new SimpleDateFormat("MMM-dd-yyyy");
            String formattedDate = dateFormat.format(selectedDate);
            pst.setString(1,"Scheduled");
              pst.setString(2,formattedDate);
            pst.setString(3,sc);
            

            pst.executeUpdate();
          JOptionPane.showMessageDialog(this, "Updated Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

          BlotterTable();
          schedule.dispose();
          Status.dispose();
          jComboBox1.setSelectedIndex(0);
          combo_day.setSelectedIndex(0);
            }
        } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
        }
    }//GEN-LAST:event_update_on_schedActionPerformed

    private void code_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_code_tfActionPerformed

    }//GEN-LAST:event_code_tfActionPerformed
 void loadImages() {
        images = new ArrayList<>();
        String query = "SELECT Image1, Image2, Image3 FROM settings";
        try {
             pst = conn.prepareStatement(query);
             ResultSet rs = pst.executeQuery();

           if (rs.next()) {
            byte[] imgBytes1 = rs.getBytes("Image1");
            if (imgBytes1 != null) {
                InputStream in1 = new ByteArrayInputStream(imgBytes1);
                ImageIcon imageIcon1 = new ImageIcon(javax.imageio.ImageIO.read(in1));
                images.add(imageIcon1);
               
            }

            byte[] imgBytes2 = rs.getBytes("Image2");
            if (imgBytes2 != null) {
                InputStream in2 = new ByteArrayInputStream(imgBytes2);
                ImageIcon imageIcon2 = new ImageIcon(javax.imageio.ImageIO.read(in2));
                images.add(imageIcon2);
           
            }

            byte[] imgBytes3 = rs.getBytes("Image3");
            if (imgBytes3 != null) {
                InputStream in3 = new ByteArrayInputStream(imgBytes3);
                ImageIcon imageIcon3 = new ImageIcon(javax.imageio.ImageIO.read(in3));
                images.add(imageIcon3);
              
            }
           }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
private ImageIcon resizeImageIcon(ImageIcon imageIcon, int width, int height) {
    Image img = imageIcon.getImage();
    Image resizedImage = img.getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH);
    return new ImageIcon(resizedImage);
}
  
    public static void main(String args[]) {
 
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Homepage_SuperAdmin_2_1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Addblotter_bt;
    private javax.swing.JButton Announce_bt;
    private javax.swing.JDialog Code;
    private javax.swing.JDialog Contact;
    private javax.swing.JMenuItem DELETE;
    private javax.swing.JPanel DashBoard_BT;
    private javax.swing.JPanel Dashboard_PL;
    private javax.swing.JMenuItem EDIT;
    private javax.swing.JPanel Head_Panel;
    private javax.swing.JFrame Help;
    public static javax.swing.JLabel IMAGE_SHARE;
    private javax.swing.JLabel IMG4;
    private javax.swing.JLabel IMG5;
    private javax.swing.JLabel IMG6;
    private javax.swing.JButton Print;
    private javax.swing.JPanel PrintPanel;
    private javax.swing.JDialog Status;
    private javax.swing.JDialog UPDATE;
    private javax.swing.JButton UpdateText;
    private javax.swing.JButton Update_bt;
    private javax.swing.JButton UploadIMG1;
    private javax.swing.JButton UploadIMG2;
    private javax.swing.JButton UploadIMG3;
    public static javax.swing.JTextArea WhatsNew;
    private javax.swing.JTextArea WhatsNew1;
    private javax.swing.JLabel X_CODE;
    private javax.swing.JLabel accname;
    public static javax.swing.JTextField add_acc_edit;
    private javax.swing.JButton add_btn;
    public static javax.swing.JTextField add_com_edit;
    private javax.swing.JPanel addblotter_pl;
    private javax.swing.JTextField address_accuse;
    private javax.swing.JTextField address_complainant;
    private javax.swing.JPanel announce_pl;
    private javax.swing.JTable blotters_table;
    private javax.swing.JTable blotters_table1;
    private javax.swing.JLabel case1;
    public static javax.swing.JLabel case_num;
    private javax.swing.JLabel casename;
    private javax.swing.JPasswordField code_tf;
    private javax.swing.JComboBox<String> combo_day;
    private javax.swing.JLabel comname;
    private javax.swing.JLabel comname1;
    private javax.swing.JLabel contact;
    private javax.swing.JLabel contact1;
    private javax.swing.JLabel date;
    private javax.swing.JLabel date_today1;
    public static javax.swing.JTextArea detail_edit;
    private javax.swing.JTextArea detailed_report_ta;
    private javax.swing.JLabel help;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    public static javax.swing.JTextArea loc_edit;
    private javax.swing.JTextArea location_ta;
    public static javax.swing.JTextField name_acc_edit;
    private javax.swing.JTextField name_accuse;
    public static javax.swing.JTextField name_com_edit;
    private javax.swing.JTextField name_complainant;
    public static javax.swing.JTextArea report_edit;
    private javax.swing.JTextArea report_ta;
    private javax.swing.JLabel reportname;
    private javax.swing.JLabel sched;
    private com.toedter.calendar.JDateChooser sched_date;
    private javax.swing.JLabel sched_date_today1;
    private javax.swing.JTextField sched_time;
    private javax.swing.JLabel sched_time_today;
    private javax.swing.JFrame schedule;
    private javax.swing.JTextField searchbar_tf;
    private javax.swing.JTextField searchbar_tf1;
    private javax.swing.JLabel set;
    private javax.swing.JButton status_bt;
    private javax.swing.JPanel status_pl;
    private javax.swing.JLabel time;
    private javax.swing.JTable today_sched;
    private javax.swing.JLabel unsched;
    private javax.swing.JLabel unset;
    private javax.swing.JButton update_on_sched;
    private javax.swing.JPanel update_pl;
    private javax.swing.JMenuItem update_status;
    private javax.swing.JButton update_status_btn;
    public static javax.swing.JLabel username_homepage;
    private javax.swing.JButton view_bt;
    private javax.swing.JPanel view_pl;
    // End of variables declaration//GEN-END:variables
private String imagePathStr;
private ImageIcon format = null;

private ImageIcon ResizeImage1(String imgPath) {

        ImageIcon myImage = new ImageIcon(imgPath);
        Image img = myImage.getImage();
        Image newImage = img.getScaledInstance(IMG4.getWidth(), IMG4.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        return image;

    }

    private ImageIcon ResizeImage2(String imgPath) {

        ImageIcon myImage = new ImageIcon(imgPath);
        Image img = myImage.getImage();
        Image newImage = img.getScaledInstance(IMG5.getWidth(), IMG5.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        return image;

    }

    private ImageIcon ResizeImage3(String imgPath) {

        ImageIcon myImage = new ImageIcon(imgPath);
        Image img = myImage.getImage();
        Image newImage = img.getScaledInstance(IMG6.getWidth(), IMG6.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        return image;

    }
    
   void showImageAndWhatsNew() {
        try {
            String sql = "SELECT IDNo, Image1, Image2, Image3, Announce FROM settings WHERE IDNo = '1'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();

            if (rs.next()) {
                String whatsNew = rs.getString("Announce");
                WhatsNew.setText(whatsNew);
                WhatsNew1.setText(whatsNew);
            }
        } catch (Exception e) {

        }
    }
   private void CaseNumber()
   {
    String query = "SELECT * FROM addblotter WHERE case_blotter=(SELECT MAX(case_blotter) FROM addblotter);";
       try {
            pst = conn.prepareStatement(query);
            rs = pst.executeQuery();
           if(rs.next())
           {
           case1.setText(rs.getString("case_blotter"));
           int num = Integer.parseInt(case1.getText());
               ++num;
              case1.setText(Integer.toString(num));
           }
           
          
       } catch (Exception e) {
       }
   }

    void BlotterTable() {
        
      try {
            pst = conn.prepareStatement("SELECT `case_blotter`, `date_blotter`, `time_blotter`, `report_blotter`, `location_blotter`, `complainant_blotter`, `address_complainant`, `accused_blotter`, `address_accused`, `detailed_report`, `status_blotter`, CONCAT(`date_status`,'/', `time_status`) AS Scheduled,name_of_username FROM `addblotter`");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) blotters_table.getModel();
            model.setRowCount(0);
            while(rs.next()){
           
            model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13)});
            }

        } catch (Exception e) {

        }
    }  
    void BlotterTable1() {
        
      try {
            pst = conn.prepareStatement("SELECT * FROM addblotter WHERE status_blotter = 'Scheduled'");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) blotters_table1.getModel();
            model.setRowCount(0);
            while(rs.next()){
           
            model.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10)});
            }

        } catch (Exception e) {

        }
    }  
    void updateAccount() {
        try {
            int row = blotters_table.getSelectedRow();
            String idno = (blotters_table.getModel().getValueAt(row, 0).toString());

            String sql = "UPDATE addblotter SET report_blotter = ?, location_blotter = ?, complainant_blotter = ?, "
                    + "address_complainant = ?, accused_blotter = ?, address_accused = ?, detailed_report = ? WHERE case_blotter ='" + idno + "'";
            pst = conn.prepareStatement(sql);

            pst.setString(1, report_edit.getText());
            pst.setString(2, loc_edit.getText());
            pst.setString(3, name_com_edit.getText());
            pst.setString(4, add_com_edit.getText());
            pst.setString(5, name_acc_edit.getText());
            pst.setString(6, add_acc_edit.getText());
            pst.setString(7, detail_edit.getText());

            pst.execute();

            JOptionPane.showMessageDialog(this, "Successfully Update!", "Update", JOptionPane.INFORMATION_MESSAGE);

            BlotterTable();

            UPDATE.dispose();
            

        } catch (Exception e) {
  Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
        }
    }
     void deleteBrgyInfo() {
        try {
            int row = blotters_table.getSelectedRow();
            String idno = (blotters_table.getModel().getValueAt(row, 0).toString());
        if(idno == null){
           JOptionPane.showMessageDialog(null,"Select An Account to Delete");
        }else{
         pst = conn.prepareStatement("DELETE FROM addblotter WHERE case_blotter = ?");
            pst.setString(1, idno);
            pst.execute();
        }
        } catch (Exception e) {

        }
    }
    
      
      void status_label(){
          String sql = "SELECT COUNT(*) FROM addblotter WHERE status_blotter = 'Settled'";
          try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String v = rs.getString("COUNT(*)");
            set.setText(v);
            
            }
          } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
          }
      }
      void status_label1(){
          String sql = "SELECT COUNT(*) FROM addblotter WHERE status_blotter = 'Unsettled'";
          try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String v = rs.getString("COUNT(*)");
            unset.setText(v);
            
            }
          } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
          }
      }
      void status_label2(){
          String sql = "SELECT COUNT(*) FROM addblotter WHERE status_blotter = 'Scheduled'";
          try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String v = rs.getString("COUNT(*)");
            sched.setText(v);
            
            }
          } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
          }
      }
      void status_label3(){
          String sql = "SELECT COUNT(*) FROM addblotter WHERE status_blotter = 'Unscheduled'";
          try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            String v = rs.getString("COUNT(*)");
            unsched.setText(v);
            
            }
          } catch (Exception e) {
               Logger.getLogger(Homepage_SuperAdmin_2.class.getName()).log(Level.SEVERE, null, e);
          }
      }
       void printField(JPanel panel) {

        PrinterJob printerjob = PrinterJob.getPrinterJob();

        printerjob.setJobName("Print Record");

        printerjob.setPrintable(new Printable() {
            @Override
            public int print(Graphics grphcs, PageFormat pf, int i) throws PrinterException {

                if (i > 0) {
                    return Printable.NO_SUCH_PAGE;
                }

                Graphics2D graphics2D = (Graphics2D) grphcs;
                double scaleX = pf.getImageableWidth() / panel.getWidth();
                double scaleY = pf.getImageableHeight() / panel.getHeight();
                double scale = Math.min(scaleX, scaleY);

                double panelWidth = panel.getWidth() * scale;
                double panelHeight = panel.getHeight() * scale;
                double translateX = (pf.getImageableWidth() - panelWidth) / 2;
                double translateY = (pf.getImageableHeight() - panelHeight) / 2;

                graphics2D.translate(pf.getImageableX() + translateX, pf.getImageableY() + translateY);
                graphics2D.scale(scale, scale);

                panel.paint(graphics2D);

                JOptionPane.showMessageDialog(null, "Print Successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

                return Printable.PAGE_EXISTS;
            }
        });

        boolean returningResult = printerjob.printDialog();

        if (returningResult) {
            try {
                printerjob.print();
            } catch (PrinterException printerException) {
                JOptionPane.showMessageDialog(this, "Print Error: " + printerException.getMessage());
            }
        }

    }

       void TODAY() {
        String datie = date.getText();
      try {
            pst = conn.prepareStatement("SELECT \n" +
"    CONCAT(\n" +
"        UPPER(SUBSTRING(complainant_blotter, 1, 1)), \n" +
"        LOWER(SUBSTRING(complainant_blotter, 2)), \n" +
"        ' - ', \n" +
"        date_status, \n" +
"        ' ', \n" +
"        time_status\n" +
"    ) AS Scheduled \n" +
"FROM \n" +
"    addblotter \n" +
"WHERE \n" +
"    date_status LIKE '%"+ datie +"%'");
            ResultSet rs = pst.executeQuery();
            DefaultTableModel model = (DefaultTableModel) today_sched.getModel();
            model.setRowCount(0);
            while(rs.next()){
           
            model.addRow(new String[]{rs.getString(1)});
            }

        } catch (Exception e) {

        }
    }  
 private String getMonthName(int monthNum) {
    switch (monthNum) {
        case 1: return "January";
        case 2: return "February";
        case 3: return "March";
        case 4: return "April";
        case 5: return "May";
        case 6: return "June";
        case 7: return "July";
        case 8: return "August";
        case 9: return "September";
        case 10: return "October";
        case 11: return "November";
        case 12: return "December";
        default: return "";
    }
}

}
