/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package blottersystem;
import static blottersystem.Server.DBName;
import static blottersystem.Server.HName;
import static blottersystem.Server.Pass;
import static blottersystem.Server.UName;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author jcram
 */
public class BlotterSystem {

    /**
     * @param args the command line arguments
     */
   public static Connection connect() {

        Connection conn = null;

        try {
            
//            String hostName = HName.getText();
//            String databaseName = DBName.getText();
//            String username = UName.getText();
//            String password = Pass.getText();
//
//            conn = DriverManager.getConnection("jdbc:mysql://" + hostName + ":3306/" + databaseName + "", "" + username + "", "" + password + "");

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pinagsanjanbms","root","");
               
            Component rootPane = null;

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Connection Error", "Error", JOptionPane.ERROR_MESSAGE);

        }
       return conn;
      
          
   }
   }
    

